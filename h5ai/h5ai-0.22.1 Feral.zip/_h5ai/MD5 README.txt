This md5 file check will match exactly all files to the official version 0.22.1 except for 1.

Except for the necessary edits to the /_h5ai/server/php/inc/init.php

This is just to show that there are no other edits to this release.